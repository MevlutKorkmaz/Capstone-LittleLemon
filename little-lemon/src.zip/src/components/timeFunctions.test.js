import { initializeTimes, updateTimes } from './Main';

test('initializeTimes returns correct initial times', () => {
  const expectedTimes = ['17:00', '18:00', '19:00', '20:00', '21:00'];
  const times = initializeTimes();
  expect(times).toEqual(expectedTimes);
});

test('updateTimes returns the same times provided in the state', () => {
  const initialState = ['17:00', '18:00', '19:00', '20:00', '21:00'];
  const action = { type: 'UPDATE_TIMES', date: '2023-09-01' };
  const updatedTimes = updateTimes(initialState, action);
  expect(updatedTimes).toEqual(initialState);
});
