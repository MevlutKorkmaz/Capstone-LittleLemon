import React, { useReducer } from 'react';
import Homepage from './Homepage';
import BookingPage from './BookingPage';

const initializeTimes = () => {
  return ['17:00', '18:00', '19:00', '20:00', '21:00'];
};

const updateTimes = (state, action) => {
  switch (action.type) {
    case 'UPDATE_TIMES':
      // Here you can update times based on the selected date
      // For now, we'll return the same available times regardless of the date
      return initializeTimes();
    default:
      return state;
  }
};

const Main = () => {
  const [availableTimes, dispatch] = useReducer(updateTimes, [], initializeTimes);

  return (
    <main>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route
          path="/booking"
          element={<BookingPage availableTimes={availableTimes} dispatch={dispatch} />}
        />
      </Routes>
    </main>
  );
};

export default Main;
