import React from 'react';
import BookingForm from './BookingForm';

const BookingPage = ({ availableTimes, dispatch }) => {
  return (
    <main>
      <h1>Book a Table</h1>
      <p>Fill in the form below to reserve your table.</p>
      <BookingForm availableTimes={availableTimes} dispatch={dispatch} />
    </main>
  );
};

export default BookingPage;
